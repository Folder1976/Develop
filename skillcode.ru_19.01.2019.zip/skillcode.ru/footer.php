    <footer class="page_footer">
        <div class="wrapper">
            <div class="contacts"><a href="mailto:folder.list@gmail.com" target="_blank">folder.list@gmail.com</a>
                <p>tel: viber: whatsapp: telegram:</p><a href="tel:+380672586999">+380672586999</a>
                <p>skype: kottem</p>
            </div>
            <ul class="socials container">
                <li><a href="" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="" title="Google Plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                <li><a href="" title="Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="" title="Youtube"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                <li><a href="" title="Skype"><i class="fa fa-skype" aria-hidden="true"></i></a></li>
            </ul>
            <p class="copyright">© 2014 - <?php echo date('Y'); ?> Orange. All Rights Reserved.</p>
        </div>
    </footer>
    <a class="button-top" href="#top" title="Наверх"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>
    <script src="scripts/libs/jquery-3.2.1.min.js"></script>
    <script src="scripts/libs/wow.min.js"></script>
    <script src="scripts/common.js"></script>
</body>
</html>