<?php
// HTTP
define('HTTP_SERVER', 'http://cn08183.tmweb.ru/admin/');
define('HTTP_CATALOG', 'http://cn08183.tmweb.ru/');

// HTTPS
define('HTTPS_SERVER', 'http://cn08183.tmweb.ru/admin/');
define('HTTPS_CATALOG', 'http://cn08183.tmweb.ru/');

// DIR
define('DIR_APPLICATION', '/home/c/cn08183/public_html/admin/');
define('DIR_SYSTEM', '/home/c/cn08183/public_html/system/');
define('DIR_IMAGE', '/home/c/cn08183/public_html/image/');
define('DIR_LANGUAGE', '/home/c/cn08183/public_html/admin/language/');
define('DIR_TEMPLATE', '/home/c/cn08183/public_html/admin/view/template/');
define('DIR_CONFIG', '/home/c/cn08183/public_html/system/config/');
define('DIR_CACHE', '/home/c/cn08183/public_html/system/storage/cache/');
define('DIR_DOWNLOAD', '/home/c/cn08183/public_html/system/storage/download/');
define('DIR_LOGS', '/home/c/cn08183/public_html/system/storage/logs/');
define('DIR_MODIFICATION', '/home/c/cn08183/public_html/system/storage/modification/');
define('DIR_UPLOAD', '/home/c/cn08183/public_html/system/storage/upload/');
define('DIR_CATALOG', '/home/c/cn08183/public_html/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'cn08183_folder');
define('DB_PASSWORD', 'cn08183_folder');
define('DB_DATABASE', 'cn08183_folder');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
