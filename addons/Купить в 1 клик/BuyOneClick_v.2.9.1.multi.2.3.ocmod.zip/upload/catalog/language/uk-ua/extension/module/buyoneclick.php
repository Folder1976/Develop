<?php
$_['buyoneclick_field1_title'] = 'Ім\'я';
$_['buyoneclick_field2_title'] = 'Телефон';
$_['buyoneclick_field3_title'] = 'E-mail';
$_['buyoneclick_field4_title'] = 'Повідомлення';
$_['buyoneclick_button_order'] = 'Відправити';
$_['buyoneclick_required_text'] = 'обовя\'зкове поле';
$_['buyoneclick_success'] = 'Дякуємо за ваше замовлення!<br />В найближчий час з Вами зв\'яжуться наші менеджери!';
$_['buyoneclick_error_required'] = 'Будь ласка, заповніть обов\'язкові поля!';
$_['buyoneclick_error_sending'] = 'Помилка, спробуйте пізніше!';
$_['buyoneclick_text_agree'] = 'Я прочитал(а) и согласен(на) с  <a href="%s" class="agree"><b>%s</b></a>';