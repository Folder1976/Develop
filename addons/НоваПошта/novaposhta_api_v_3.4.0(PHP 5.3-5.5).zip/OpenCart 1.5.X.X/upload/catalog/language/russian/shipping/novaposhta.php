<?php
// Text
$_['text_title']                 = 'Новая Почта';
$_['text_description_warehouse'] = 'Доставка в отделение Новой Почты';
$_['text_description_doors']     = 'Доставка курьером Новой Почты на адрес';
$_['text_period']                = 'Срок доставки - ';
$_['text_day_1']                 = 'день';
$_['text_day_2']                 = 'дня';
$_['text_day_3']                 = 'дней';