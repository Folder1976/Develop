<?php
// Text
$_['text_title']                 = 'Nova Poshta';
$_['text_description_warehouse'] = 'Delivery to the warehouse of Nova Poshta';
$_['text_description_doors']     = 'Nova Poshta courier shipping to the address';
$_['text_period']                = 'Delivery time - ';
$_['text_day_1']                 = 'day';
$_['text_day_2']                 = 'days';
$_['text_day_3']                 = 'days';