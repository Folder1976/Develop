<?php
// Heading
$_['heading_title']  = 'Кастомная цена';
$_['text_extension'] = 'Расширения';
$_['text_success']   = 'Настройки успешно изменены!';
$_['text_edit']      = 'Настройки модуля';
$_['entry_status']   = 'Статус';
$_['text_enabled']   = 'Включено';
$_['text_disabled']  = 'Выключено';

// Text
$_['text_price_title']  = 'Настройка цен';
$_['text_price']        = 'Цена';
$_['text_price_retail']       = 'Розница';
$_['text_price_box']       = 'Упаковка';
$_['text_price_wholesale']       = 'Опт';
$_['text_wholesale']       = 'Считать покупку оптовой при закзазе на сумму от:';
$_['text_recount']      = 'Пересчитать';
